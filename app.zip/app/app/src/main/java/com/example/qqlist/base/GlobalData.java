package com.example.qqlist.base;

public class GlobalData {
    public static  String getStr_shanghai_beijing="{\n" +
            "    \"status\": 0,\n" +
            "    \"msg\": \"ok\",\n" +
            "    \"result\": {\n" +
            "        \"start\": \"上海\",\n" +
            "        \"end\": \"北京\",\n" +
            "        \"ishigh\": \"\",\n" +
            "        \"date\": \"2019-12-17\",\n" +
            "        \"list\": [\n" +
            "            {\n" +
            "                \"trainno\": \"G102\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"06:26\",\n" +
            "                \"arrivaltime\": \"12:29\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时3分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G10200\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G104\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"06:38\",\n" +
            "                \"arrivaltime\": \"12:33\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时55分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G10470\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G6\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"07:00\",\n" +
            "                \"arrivaltime\": \"11:38\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"4时38分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"55000000G601\",\n" +
            "                \"pricesw\": 1762.5,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"939.0\",\n" +
            "                \"priceed\": \"558.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G110\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"07:28\",\n" +
            "                \"arrivaltime\": \"13:38\",\n" +
            "                \"sequenceno\": 2,\n" +
            "                \"costtime\": \"6时10分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G110C0\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": 1053,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G8\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"08:00\",\n" +
            "                \"arrivaltime\": \"12:24\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"4时24分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l000000G815\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G112\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"08:05\",\n" +
            "                \"arrivaltime\": \"14:08\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时3分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G11295\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G114\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"08:15\",\n" +
            "                \"arrivaltime\": \"14:13\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时58分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G11480\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G116\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"09:34\",\n" +
            "                \"arrivaltime\": \"15:23\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时49分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G11680\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G118\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"09:52\",\n" +
            "                \"arrivaltime\": \"15:58\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时6分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G11803\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": 1053,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G122\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"10:41\",\n" +
            "                \"arrivaltime\": \"16:43\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时2分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G122B0\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G130\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"11:15\",\n" +
            "                \"arrivaltime\": \"17:29\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时14分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"550000G13000\",\n" +
            "                \"pricesw\": 1762.5,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"939.0\",\n" +
            "                \"priceed\": \"558.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"1462\",\n" +
            "                \"type\": \"O\",\n" +
            "                \"station\": \"上海\",\n" +
            "                \"endstation\": \"北京\",\n" +
            "                \"departuretime\": \"12:18\",\n" +
            "                \"arrivaltime\": \"10:50\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"22时32分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"550000146200\",\n" +
            "                \"pricesw\": null,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricerz\": null,\n" +
            "                \"priceyz\": 156.5,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": 455.5,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": 283.5,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"空车体返回列车\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G412\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"12:28\",\n" +
            "                \"arrivaltime\": \"18:53\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时25分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G41260\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G134\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"13:00\",\n" +
            "                \"arrivaltime\": \"18:48\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时48分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G134B0\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G138\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"13:29\",\n" +
            "                \"arrivaltime\": \"19:28\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时59分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G13861\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G140\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"13:34\",\n" +
            "                \"arrivaltime\": \"19:41\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时7分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G14051\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G4\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"14:00\",\n" +
            "                \"arrivaltime\": \"18:28\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"4时28分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l000000G433\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G142\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"14:10\",\n" +
            "                \"arrivaltime\": \"20:18\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时8分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G14261\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": 1053,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G144\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"14:42\",\n" +
            "                \"arrivaltime\": \"20:29\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时47分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G144T0\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G146\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"14:50\",\n" +
            "                \"arrivaltime\": \"20:48\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时58分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G146F0\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": 1053,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G170\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"15:52\",\n" +
            "                \"arrivaltime\": \"21:18\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时26分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G17004\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G154\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"17:13\",\n" +
            "                \"arrivaltime\": \"22:48\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时35分\",\n" +
            "                \"distance\": 950,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G15481\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G156\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"17:18\",\n" +
            "                \"arrivaltime\": \"22:58\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时40分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G156Y0\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G44\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"17:23\",\n" +
            "                \"arrivaltime\": \"23:08\",\n" +
            "                \"sequenceno\": 4,\n" +
            "                \"costtime\": \"5时45分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5600000G4400\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G158\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"17:34\",\n" +
            "                \"arrivaltime\": \"23:29\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时55分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G158D1\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G160\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"17:46\",\n" +
            "                \"arrivaltime\": \"23:48\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时2分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G16001\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"D708\",\n" +
            "                \"type\": \"D\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"19:17\",\n" +
            "                \"arrivaltime\": \"07:11\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"11时54分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000D70821\",\n" +
            "                \"pricesw\": null,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"动车\",\n" +
            "                \"priceyd\": \"296.0\",\n" +
            "                \"priceed\": \"247.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"Z282\",\n" +
            "                \"type\": \"Z\",\n" +
            "                \"station\": \"上海南\",\n" +
            "                \"endstation\": \"北京\",\n" +
            "                \"departuretime\": \"19:30\",\n" +
            "                \"arrivaltime\": \"10:22\",\n" +
            "                \"sequenceno\": 4,\n" +
            "                \"costtime\": \"14时52分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 0,\n" +
            "                \"trainno12306\": \"560000Z28230\",\n" +
            "                \"pricesw\": 563.5,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricerz\": 281.5,\n" +
            "                \"priceyz\": 177.5,\n" +
            "                \"pricegr1\": 513.5,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": 476.5,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": 304.5,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"直达特快\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G136\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"上海虹桥\",\n" +
            "                \"endstation\": \"北京南\",\n" +
            "                \"departuretime\": \"24:00\",\n" +
            "                \"arrivaltime\": \"24:00\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时46分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"5l0000G136Y0\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            }\n" +
            "        ]\n" +
            "    }\n" +
            "}\n";
   public static String str_beijing_shanghai= "{\n" +
            "    \"status\": 0,\n" +
            "    \"msg\": \"ok\",\n" +
            "    \"result\": {\n" +
            "        \"start\": \"北京\",\n" +
            "        \"end\": \"上海\",\n" +
            "        \"ishigh\": \"\",\n" +
            "        \"date\": \"2019-12-16\",\n" +
            "        \"list\": [\n" +
            "            {\n" +
            "                \"trainno\": \"G101\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"06:36\",\n" +
            "                \"arrivaltime\": \"12:40\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时57分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1010I\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G103\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"06:43\",\n" +
            "                \"arrivaltime\": \"12:48\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时4分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1032N\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G5\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海\",\n" +
            "                \"departuretime\": \"07:00\",\n" +
            "                \"arrivaltime\": \"11:40\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"4时40分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"24000000G505\",\n" +
            "                \"pricesw\": 1762.5,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"939.0\",\n" +
            "                \"priceed\": \"558.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G107\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"08:05\",\n" +
            "                \"arrivaltime\": \"13:46\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时41分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1070J\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G115\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"09:20\",\n" +
            "                \"arrivaltime\": \"14:58\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时39分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G11513\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G7\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"10:00\",\n" +
            "                \"arrivaltime\": \"14:28\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"4时28分\",\n" +
            "                \"distance\": 1334,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"24000000G706\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G119\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"10:05\",\n" +
            "                \"arrivaltime\": \"15:51\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时46分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1190F\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G121\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"10:20\",\n" +
            "                \"arrivaltime\": \"16:25\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时5分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1210L\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G123\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"11:05\",\n" +
            "                \"arrivaltime\": \"16:50\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时45分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1232A\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G411\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"11:20\",\n" +
            "                \"arrivaltime\": \"17:25\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时5分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G4110C\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G127\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"11:30\",\n" +
            "                \"arrivaltime\": \"17:20\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时50分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1272X\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"1461\",\n" +
            "                \"type\": \"O\",\n" +
            "                \"station\": \"北京\",\n" +
            "                \"endstation\": \"上海\",\n" +
            "                \"departuretime\": \"11:55\",\n" +
            "                \"arrivaltime\": \"07:00\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"19时5分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"24000014611W\",\n" +
            "                \"pricesw\": 521.5,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricerz\": 260.5,\n" +
            "                \"priceyz\": 156.5,\n" +
            "                \"pricegr1\": 492.5,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": 455.5,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": 283.5,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"空车体返回列车\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G137\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"13:35\",\n" +
            "                \"arrivaltime\": \"19:17\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时42分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1370V\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G43\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"14:05\",\n" +
            "                \"arrivaltime\": \"19:43\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时38分\",\n" +
            "                \"distance\": 1336,\n" +
            "                \"isend\": 0,\n" +
            "                \"trainno12306\": \"2400000G430C\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G145\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"14:35\",\n" +
            "                \"arrivaltime\": \"20:33\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时58分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1450R\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G11\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"15:00\",\n" +
            "                \"arrivaltime\": \"19:28\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"4时28分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"2400000G110L\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G155\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"15:45\",\n" +
            "                \"arrivaltime\": \"21:41\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时56分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 0,\n" +
            "                \"trainno12306\": \"240000G1551Y\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": 1053,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G147\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"15:50\",\n" +
            "                \"arrivaltime\": \"22:00\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"6时10分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1470G\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G157\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"17:36\",\n" +
            "                \"arrivaltime\": \"23:32\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"5时56分\",\n" +
            "                \"distance\": 1318,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000G1570O\",\n" +
            "                \"pricesw\": 1748,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"933.0\",\n" +
            "                \"priceed\": \"553.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"G21\",\n" +
            "                \"type\": \"G\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海\",\n" +
            "                \"departuretime\": \"19:08\",\n" +
            "                \"arrivaltime\": \"23:40\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"4时32分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"2400000G2109\",\n" +
            "                \"pricesw\": 1762.5,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"高铁\",\n" +
            "                \"priceyd\": \"939.0\",\n" +
            "                \"priceed\": \"558.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"Z284\",\n" +
            "                \"type\": \"Z\",\n" +
            "                \"station\": \"北京\",\n" +
            "                \"endstation\": \"上海南\",\n" +
            "                \"departuretime\": \"19:10\",\n" +
            "                \"arrivaltime\": \"09:54\",\n" +
            "                \"sequenceno\": 8,\n" +
            "                \"costtime\": \"14时44分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 0,\n" +
            "                \"trainno12306\": \"330000Z2840E\",\n" +
            "                \"pricesw\": 563.5,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricerz\": 281.5,\n" +
            "                \"priceyz\": 177.5,\n" +
            "                \"pricegr1\": 513.5,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": 476.5,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": 304.5,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"直达特快\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"D701\",\n" +
            "                \"type\": \"D\",\n" +
            "                \"station\": \"北京\",\n" +
            "                \"endstation\": \"上海\",\n" +
            "                \"departuretime\": \"19:22\",\n" +
            "                \"arrivaltime\": \"07:26\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"12时4分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000D70100\",\n" +
            "                \"pricesw\": null,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": 858,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": 677,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"动车\",\n" +
            "                \"priceyd\": \"451.0\",\n" +
            "                \"priceed\": \"451.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"D707\",\n" +
            "                \"type\": \"D\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"19:36\",\n" +
            "                \"arrivaltime\": \"07:41\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"12时5分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000D70703\",\n" +
            "                \"pricesw\": null,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"动车\",\n" +
            "                \"priceyd\": \"323.0\",\n" +
            "                \"priceed\": \"247.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"D709\",\n" +
            "                \"type\": \"D\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海\",\n" +
            "                \"departuretime\": \"19:46\",\n" +
            "                \"arrivaltime\": \"07:46\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"12时0分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000D70900\",\n" +
            "                \"pricesw\": null,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": 853,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": 673,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"动车\",\n" +
            "                \"priceyd\": \"449.0\",\n" +
            "                \"priceed\": \"449.0\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"trainno\": \"D703\",\n" +
            "                \"type\": \"D\",\n" +
            "                \"station\": \"北京南\",\n" +
            "                \"endstation\": \"上海虹桥\",\n" +
            "                \"departuretime\": \"24:00\",\n" +
            "                \"arrivaltime\": \"24:00\",\n" +
            "                \"sequenceno\": 1,\n" +
            "                \"costtime\": \"12时1分\",\n" +
            "                \"distance\": 0,\n" +
            "                \"isend\": 1,\n" +
            "                \"trainno12306\": \"240000D70320\",\n" +
            "                \"pricesw\": null,\n" +
            "                \"pricetd\": null,\n" +
            "                \"pricegr1\": null,\n" +
            "                \"pricegr2\": null,\n" +
            "                \"pricerw1\": null,\n" +
            "                \"pricerw2\": null,\n" +
            "                \"priceyw1\": null,\n" +
            "                \"priceyw2\": null,\n" +
            "                \"priceyw3\": null,\n" +
            "                \"typename\": \"动车\",\n" +
            "                \"priceyd\": \"350.0\",\n" +
            "                \"priceed\": \"292.0\"\n" +
            "            }\n" +
            "        ]\n" +
            "    }\n" +
            "}";

   public static String str_tq_beijing="{\n" +
           "\t\"reason\":\"查询成功!\",\n" +
           "\t\"result\":{\n" +
           "\t\t\"city\":\"北京\",\n" +
           "\t\t\"realtime\":{\n" +
           "\t\t\t\"temperature\":\"3\",\n" +
           "\t\t\t\"humidity\":\"30\",\n" +
           "\t\t\t\"info\":\"晴\",\n" +
           "\t\t\t\"wid\":\"00\",\n" +
           "\t\t\t\"direct\":\"北风\",\n" +
           "\t\t\t\"power\":\"4级\",\n" +
           "\t\t\t\"aqi\":\"21\"\n" +
           "\t\t},\n" +
           "\t\t\"future\":[\n" +
           "\t\t\t{\n" +
           "\t\t\t\t\"date\":\"2019-12-17\",\n" +
           "\t\t\t\t\"temperature\":\"-6\\/6℃\",\n" +
           "\t\t\t\t\"weather\":\"晴\",\n" +
           "\t\t\t\t\"wid\":{\n" +
           "\t\t\t\t\t\"day\":\"00\",\n" +
           "\t\t\t\t\t\"night\":\"00\"\n" +
           "\t\t\t\t},\n" +
           "\t\t\t\t\"direct\":\"北风\"\n" +
           "\t\t\t},\n" +
           "\t\t\t{\n" +
           "\t\t\t\t\"date\":\"2019-12-18\",\n" +
           "\t\t\t\t\"temperature\":\"-6\\/2℃\",\n" +
           "\t\t\t\t\"weather\":\"晴\",\n" +
           "\t\t\t\t\"wid\":{\n" +
           "\t\t\t\t\t\"day\":\"00\",\n" +
           "\t\t\t\t\t\"night\":\"00\"\n" +
           "\t\t\t\t},\n" +
           "\t\t\t\t\"direct\":\"西南风转北风\"\n" +
           "\t\t\t},\n" +
           "\t\t\t{\n" +
           "\t\t\t\t\"date\":\"2019-12-19\",\n" +
           "\t\t\t\t\"temperature\":\"-8\\/5℃\",\n" +
           "\t\t\t\t\"weather\":\"晴\",\n" +
           "\t\t\t\t\"wid\":{\n" +
           "\t\t\t\t\t\"day\":\"00\",\n" +
           "\t\t\t\t\t\"night\":\"00\"\n" +
           "\t\t\t\t},\n" +
           "\t\t\t\t\"direct\":\"北风\"\n" +
           "\t\t\t},\n" +
           "\t\t\t{\n" +
           "\t\t\t\t\"date\":\"2019-12-20\",\n" +
           "\t\t\t\t\"temperature\":\"-7\\/0℃\",\n" +
           "\t\t\t\t\"weather\":\"晴\",\n" +
           "\t\t\t\t\"wid\":{\n" +
           "\t\t\t\t\t\"day\":\"00\",\n" +
           "\t\t\t\t\t\"night\":\"00\"\n" +
           "\t\t\t\t},\n" +
           "\t\t\t\t\"direct\":\"南风转北风\"\n" +
           "\t\t\t},\n" +
           "\t\t\t{\n" +
           "\t\t\t\t\"date\":\"2019-12-21\",\n" +
           "\t\t\t\t\"temperature\":\"-7\\/2℃\",\n" +
           "\t\t\t\t\"weather\":\"晴转多云\",\n" +
           "\t\t\t\t\"wid\":{\n" +
           "\t\t\t\t\t\"day\":\"00\",\n" +
           "\t\t\t\t\t\"night\":\"01\"\n" +
           "\t\t\t\t},\n" +
           "\t\t\t\t\"direct\":\"北风\"\n" +
           "\t\t\t}\n" +
           "\t\t]\n" +
           "\t},\n" +
           "\t\"error_code\":0\n" +
           "}";

    /**
     * sp保存本地数据关键key
     */
    public static final String sp_key_0 = "sp_key_0";//标记：用户登录状态。value为用户id
    public static final String sp_key_1 = "sp_key_1";//标记：设备无网，可以继续操作一小时，0：上次有网；1：无网，开始操作；2：无网，结束操作
    public static final String sp_key_2= "sp_key_2";//标记：当前界面是否在操控界面。1：是；0：不是
    public static final String sp_key_3= "sp_key_3";//标记：时卡套餐使用中(体雕)，保存临时数据。结构：oid_projectEndtime_orderUseId_packageUseId
    public static final String sp_key_4= "sp_key_4";//标记：时卡套餐使用中（爆脂），保存临时数据。结构：oid_projectEndtime_orderUseId_packageUseId

}
