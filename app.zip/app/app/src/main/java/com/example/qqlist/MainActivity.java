package com.example.qqlist;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.qqlist.bean.Beabate;
import com.example.qqlist.util.Xutils;
import com.google.gson.Gson;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import org.xutils.ex.DbException;

import java.util.ArrayList;

public class MainActivity extends Activity {

    public Context myContext;
    public Activity myActivity;
    RecyclerView mLv;
    SmartRefreshLayout mRefreshLayout;
    ArrayList<Beabate.ResponseResultBean.DynamicinfosBean> list;
    Myadapter shipeiqi;
    int page = 0;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.shuru);


        try {
            if (Xutils.initDbConfiginit().findAll(Beabate.ResponseResultBean.DynamicinfosBean.class) == null) {
                Gson gson = new Gson();
                Beabate beabate = gson.fromJson(datajson, Beabate.class);
                for (int i = 0; i < beabate.getResponseResult().getDynamicinfos().size(); i++) {
                    Xutils.initDbConfiginit().save(beabate.getResponseResult().getDynamicinfos().get(i));
                }
            }
        } catch (DbException e) {
            e.printStackTrace();
        }


        initView();
        initData();

        findViewById(R.id.sousou).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list.clear();
                page = 0;
                EditText editText = findViewById(R.id.shuru);
                String shurstring = editText.getText() + "";
                editText.setText(" ");
                try {
                    list.addAll(Xutils.initDbConfiginit().selector(Beabate.ResponseResultBean.DynamicinfosBean.class).where("id", "=", shurstring).findAll());
                } catch (DbException e) {
                    e.printStackTrace();
                }
                shipeiqi.setList(list);
                shipeiqi.notifyDataSetChanged();

            }
        });
    }

    private void initData() {
        try {
            if (page == 0) {
                list.addAll(Xutils.initDbConfiginit().selector(Beabate.ResponseResultBean.DynamicinfosBean.class).where("id", "<", "10").findAll());
            } else if (page > 0) {
                list.addAll(Xutils.initDbConfiginit().selector(Beabate.ResponseResultBean.DynamicinfosBean.class).where("id", ">", "10").findAll());
            }
        } catch (DbException e) {
            e.printStackTrace();
        }

        shipeiqi.setList(list);
        shipeiqi.notifyDataSetChanged();


    }

    private void initView() {
        mLv = (RecyclerView) findViewById(R.id.lv);
        mRefreshLayout = (SmartRefreshLayout) findViewById(R.id.refreshLayout);
        list = new ArrayList<>();
        shipeiqi = new Myadapter(this, list, R.layout.item_meal);
        mLv.setAdapter(shipeiqi);
        mLv.setLayoutManager(new LinearLayoutManager(this));
        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page++;
                initData();
                shipeiqi.notifyDataSetChanged();
                refreshLayout.finishLoadMore(true);//加载完成
            }
        });
        //刷新
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                list.clear();
                page = 0;
                initData();
                shipeiqi.notifyDataSetChanged();
                refreshLayout.finishRefresh(true);//刷新完成
            }
        });
    }


    String datajson = "{\n" +
            "\t\"rtnCode\": 0,\n" +
            "\t\"rtnDesc\": \"success\",\n" +
            "\t\"responseResult\": {\n" +
            "\t\t\"totalCount\": 1,\n" +
            "\t\t\"dynamicinfos\": [{\n" +
            "\t\t\t\"ticIc\": \"1\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}, {\n" +
            "\t\t\t\"ticIc\": \"5\",\n" +
            "\t\t\t\"content\": \"岗头市场 <em style='color:green;'>煎</em> <em style='color:green;'>饼</em>\",\n" +
            "\t\t\t\"userld\": \"103\",\n" +
            "\t\t\t\"createTime\": \"20200806101450\"\n" +
            "\t\t}]\n" +
            "\t}\n" +
            "}";
}
