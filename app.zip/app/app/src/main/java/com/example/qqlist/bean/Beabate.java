package com.example.qqlist.bean;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

import java.util.List;

public class Beabate {


    /**
     * rtnCode : 0
     * rtnDesc : success
     * responseResult : {"totalCount":1,"dynamicinfos":[{"ticIc":"1","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"}]}
     */

    private int rtnCode;
    private String rtnDesc;
    private ResponseResultBean responseResult;

    public int getRtnCode() {
        return rtnCode;
    }

    public void setRtnCode(int rtnCode) {
        this.rtnCode = rtnCode;
    }

    public String getRtnDesc() {
        return rtnDesc;
    }

    public void setRtnDesc(String rtnDesc) {
        this.rtnDesc = rtnDesc;
    }

    public ResponseResultBean getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(ResponseResultBean responseResult) {
        this.responseResult = responseResult;
    }

    public static class ResponseResultBean {
        /**
         * totalCount : 1
         * dynamicinfos : [{"ticIc":"1","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"},{"ticIc":"5","content":"市场< em styIe = 'coIor:green;' > <\/em><em styIe='coIor:green;'>煎<\/em > < em styIe = 'coIor:green;' > 煎 < /em>","userld":"103","createTime":"20200806101450"}]
         */

        private int totalCount;
        private List<DynamicinfosBean> dynamicinfos;

        public int getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(int totalCount) {
            this.totalCount = totalCount;
        }

        public List<DynamicinfosBean> getDynamicinfos() {
            return dynamicinfos;
        }

        public void setDynamicinfos(List<DynamicinfosBean> dynamicinfos) {
            this.dynamicinfos = dynamicinfos;
        }
        @Table(name = "DynamicinfosBean")

        public static class DynamicinfosBean {
            /**
             * ticIc : 1
             * content : 市场< em styIe = 'coIor:green;' > </em><em styIe='coIor:green;'>煎</em > < em styIe = 'coIor:green;' > 煎 < /em>
             * userld : 103
             * createTime : 20200806101450
             */
            @Column(name = "id", isId = true,autoGen=true)
            private int id;
            @Column(name = "ticIc")
            private String ticIc;
            @Column(name = "content")

            private String content;
            @Column(name = "userld")

            private String userld;
            @Column(name = "createTime")

            private String createTime;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTicIc() {
                return ticIc;
            }

            public void setTicIc(String ticIc) {
                this.ticIc = ticIc;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getUserld() {
                return userld;
            }

            public void setUserld(String userld) {
                this.userld = userld;
            }

            public String getCreateTime() {
                return createTime;
            }

            public void setCreateTime(String createTime) {
                this.createTime = createTime;
            }
        }
    }
}
