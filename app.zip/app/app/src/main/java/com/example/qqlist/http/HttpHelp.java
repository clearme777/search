package com.example.qqlist.http;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telecom.Call;
import android.widget.Toast;

import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.HttpParams;
import com.lzy.okgo.model.Response;
import com.orhanobut.logger.Logger;

import org.json.JSONException;

import java.util.Map;


/**
 * Created by seven on 2016/5/21.
 */
public class HttpHelp {


    I_success i_success;
    I_failure i_failure;
    Context context;
    String url;


    public HttpHelp(I_success i_success, I_failure i_failure, Context context, String url) {
        this.i_failure = i_failure;
        this.i_success = i_success;
        this.context = context;
        this.url = url;
    }

    //普通请求 post
    public void getHttp(final Map map) {
        //首先判断有无网络
        ConnectivityManager mConnectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean isHaveNetwork;//是否有网络
        // 检查网络连接，如果无网络可用，就不需要进行连网操作等
        NetworkInfo info = mConnectivity.getActiveNetworkInfo();
        if (info == null || !mConnectivity.getBackgroundDataSetting()) {
            isHaveNetwork = false;
        } else {
            isHaveNetwork = true;
        }
        if (isHaveNetwork) {
            //配置公共请求参数
//            map.put("imei", PhoneUtils.getPhoneImei());
//            String paramJson  = new Gson().toJson(map);  //1. json形式
            HttpParams paramsMap = new HttpParams();        //2. 表单形式
            paramsMap.put(map);
            OkGo.<String>post(url).tag(context).params(paramsMap).execute(new StringCallback() {
                @Override
                public void onSuccess(Response<String> response) {
                    String s = response.body();
                    Logger.v("-----------HttpURL----" + url);
                    Logger.v("-----------paramJson--" + new Gson().toJson(map));
                    Logger.v("-----------json-------" + s);

                    try {
                        i_success.doSuccess(s);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

        } else {//没有网络，弹出对话框
            Logger.v("-----------无网络-------");
            Toast.makeText(context, "无网络", Toast.LENGTH_SHORT).show();
        }
    }

    //普通请求 get
    public void getHttp2() {

        OkGo.<String>get(url).tag(context).execute(new StringCallback() {
            @Override
            public void onSuccess(Response<String> response) {
                String s = response.body();
                Logger.v("-----------2HttpURL----" + url);
                Logger.v("-----------2json-------" + response.body());
                Logger.v("-----------2json-------" + s);

                try {
                    i_success.doSuccess(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }


}
