package com.example.qqlist;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.qqlist.base.BaseRecyclerAdapter;
import com.example.qqlist.base.MyRVViewHolder;
import com.example.qqlist.bean.Beabate;
import com.example.qqlist.bean.QQBean;
import com.example.qqlist.util.MxgsaTagHandler;

import org.greenrobot.eventbus.EventBus;
import org.litepal.crud.DataSupport;

import java.util.List;

public class Myadapter extends BaseRecyclerAdapter<Beabate.ResponseResultBean.DynamicinfosBean> {

    private TextView tv_name, tv_content, tv_time;

    public Myadapter(Context context, List<Beabate.ResponseResultBean.DynamicinfosBean> datas, int layoutId) {
        super(context, datas, layoutId);
    }
    public  void setList(List<Beabate.ResponseResultBean.DynamicinfosBean> datas)
    {
        this.mDatas = datas;

    }

    @Override
    public void setView(MyRVViewHolder holder, final Beabate.ResponseResultBean.DynamicinfosBean bean, int position) {
        if (null == holder || null == bean)
            return;
        //init view
        tv_name = holder.getView(R.id.tv_name);
        tv_content = holder.getView(R.id.tv_content);
        tv_time = holder.getView(R.id.tv_time);
        //set view
      //  tv_name.setText(bean.getContent());
        tv_name.setText(Html.fromHtml(bean.getContent()));

        tv_content.setText("userid："+bean.getUserld());
       // tv_time.setText("第"+bean.getId()+"条");
        tv_time.setText(bean.getCreateTime().substring(0,4)+"年"+bean.getCreateTime().substring(4,6)+"月"+bean.getCreateTime().substring(6,8)+"日"
        + bean.getCreateTime().substring(8,10)+"时"+ bean.getCreateTime().substring(10,12)+"分"+ bean.getCreateTime().substring(12,14)+"秒");


    }
}
