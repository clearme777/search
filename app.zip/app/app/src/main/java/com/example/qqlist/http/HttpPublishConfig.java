package com.example.qqlist.http;


import java.util.Map;

/**
 * @titile 网络请求的公共参数
 * @desc Created by seven on 2018/1/18.
 */

public class HttpPublishConfig {
    public static void setPublicParam(Map map) {
        //这里封装公共参数
//        map.put("","");
    }

    public static  final String BASE_URL = "http://192.168.0.107:8080";

}
